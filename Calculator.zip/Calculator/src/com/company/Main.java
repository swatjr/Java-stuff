package com.company;

import java.io.Console;
import java.text.NumberFormat;
import java.util.Scanner;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {
	// write your code here
            int Number_of_Months = 12;
            int percent = 100
            Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Principal:");
            int principal = scanner.nextInt();
        System.out.println("Enter interest rate:");
            float rate = scanner.nextFloat() / percent;
        System.out.println("Enter Number of years:");
            int period = scanner.nextInt();
        float monthly = (rate / Number_of_Months);
        int term = (period * Number_of_Months);
        float number= (1+ monthly);


        double payment= (principal * ((monthly * Math.pow(number,term)) / ((Math.pow(number,term)-1))));


        System.out.println(payment);

    }
}
